import 'package:healtcare/auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:healtcare/pages/home_page.dart';
import 'package:healtcare/pages/login_pages.dart';
import 'package:healtcare/pages/form_page.dart';
import 'package:healtcare/pages/struk_page.dart';
import 'package:firebase_auth/firebase_auth.dart';

class WidgetTree2 extends StatefulWidget {
  const WidgetTree2({Key? key}) : super(key: key);

  @override
  State<WidgetTree2> createState() => _WidgetTree2State();
}

class _WidgetTree2State extends State<WidgetTree2> {
  String? emailU;
  final _auth = FirebaseAuth.instance;
  late User loggedInUser;

  @override
  void initState() {
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        loggedInUser = user;
        emailU = (loggedInUser.email).toString();
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('healthcare')
          .where('email', isEqualTo: emailU)
          .snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator(); // Handle loading state
        } else if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return MyForm(); // Return your widget when there is no data
        } else {
          return Struk(); // Return your widget when data is available
        }
      },
    );
  }
}
