import 'package:flutter/material.dart';
//import 'package:navigation/pages/second_pages.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:healtcare/auth.dart';


class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

@override
  State<MainPage> createState() => _MainPageState();


  // @override
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     body: Center(
  //       child: Column(
  //         mainAxisAlignment: MainAxisAlignment.center,
  //         children: [
  //           // Formulir Login
  //           Padding(
  //             padding: const EdgeInsets.all(16.0),
  //             child: Card(
  //               child: Padding(
  //                 padding: const EdgeInsets.all(16.0),
  //                 child: Column(
  //                   mainAxisAlignment: MainAxisAlignment.center,
  //                   crossAxisAlignment: CrossAxisAlignment.stretch,
  //                   children: [
  //                     //Image.asset('images/logo.png'),
  //                     Text(
  //                       "Login Helath Care",
  //                       textAlign: TextAlign.center,
  //                       style: TextStyle(
  //                         fontSize: 24.0,
  //                         fontWeight: FontWeight.bold,
  //                         color: Colors.blue,
  //                       ),
  //                     ),
  //                     SizedBox(height: 16.0),
  //                     TextFormField(
  //                       decoration: InputDecoration(labelText: 'Email'),
  //                     ),
  //                     SizedBox(height: 16.0),
  //                     TextFormField(
  //                       obscureText: true,
  //                       decoration: InputDecoration(labelText: 'Password'),
  //                     ),
  //                     SizedBox(height: 16.0),
  //                     ElevatedButton(
  //                       onPressed: () {
  //                         Navigator.pushNamed(context, '/four');
  //                       },
  //                       child: Text("Login"),
  //                     ),
  //                     SizedBox(height: 8.0),
  //                     Text(
  //                       "belum punya akun?",
  //                       style: TextStyle(
  //                         fontSize: 12.0,
  //                         color: const Color.fromARGB(255, 169, 171, 172),
  //                       ),
  //                     ),
  //                     OutlinedButton(
  //                       onPressed: () {
  //                         Navigator.pushNamed(context, '/second');
  //                       },
  //                       child: Text("Registrasi"),
  //                     ),
  //                   ],
  //                 ),
  //               ),
  //             ),
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }
}

class _MainPageState extends State<MainPage>{
String? errorMessage = '';
  bool isLogin = true;

  final TextEditingController _controllerEmail = TextEditingController();
  final TextEditingController _controllerPassword = TextEditingController();

  Future<void> signInWithEmailAndPassword() async {
    try {
      await Auth().signInWithEmailAndPassword(
          email: _controllerEmail.text, password: _controllerPassword.text);
    } on FirebaseAuthException catch (e) {
      setState(() {
        errorMessage = e.message;
      });
    }
  }

  Future<void> createUserWithEmailAndPassword() async {
    try {
      await Auth().createUserWithEmailAndPassword(
          email: _controllerEmail.text, password: _controllerPassword.text);
    } on FirebaseAuthException catch (e) {
      setState(() {
        errorMessage = e.message;
      });
    }
  }

  Widget _title() {
    return const Text('Firebase Auth');
  }

  Widget _entryField(String title, TextEditingController controller) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: title,
      ),
    );
  }

  Widget _errorMessage() {
    return Text(errorMessage == '' ? '' : '$errorMessage');
  }

  Widget _submitButton() {
    return ElevatedButton(
      onPressed:
          isLogin ? signInWithEmailAndPassword : createUserWithEmailAndPassword,
      child: Text(isLogin ? 'Login' : 'Register'),
    );
  }

  Widget _loginOrRegisterButton() {
    return TextButton(
      onPressed: () {
        setState(() {
          isLogin = !isLogin;
        });
      },
      child: Text(isLogin ? 'Register' : 'Login'),
    );
  }

 @override


 
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     body: Center(
  //       child: Column(
  //         mainAxisAlignment: MainAxisAlignment.center,
  //         children: [
  //           // Formulir Login
  //           Padding(
  //             padding: const EdgeInsets.all(16.0),
  //             child: Card(
  //               child: Padding(
  //                 padding: const EdgeInsets.all(16.0),
  //                 child: Column(
  //                   mainAxisAlignment: MainAxisAlignment.center,
  //                   crossAxisAlignment: CrossAxisAlignment.stretch,
  //                   children: [
  //                     //Image.asset('images/logo.png'),
  //                     Text(
  //                       "Login Helath Care",
  //                       textAlign: TextAlign.center,
  //                       style: TextStyle(
  //                         fontSize: 24.0,
  //                         fontWeight: FontWeight.bold,
  //                         color: Colors.blue,
  //                       ),
  //                     ),
  //                     SizedBox(height: 16.0),
  //                     TextFormField(
  //                       decoration: InputDecoration(labelText: 'Email'),
  //                     ),
  //                     SizedBox(height: 16.0),
  //                     TextFormField(
  //                       obscureText: true,
  //                       decoration: InputDecoration(labelText: 'Password'),
  //                     ),
  //                     SizedBox(height: 16.0),
  //                     ElevatedButton(
  //                       onPressed: () {
  //                         Navigator.pushNamed(context, '/four');
  //                       },
  //                       child: Text("Login"),
  //                     ),
  //                     SizedBox(height: 8.0),
  //                     Text(
  //                       "belum punya akun?",
  //                       style: TextStyle(
  //                         fontSize: 12.0,
  //                         color: const Color.fromARGB(255, 169, 171, 172),
  //                       ),
  //                     ),
  //                     OutlinedButton(
  //                       onPressed: () {
  //                         Navigator.pushNamed(context, '/second');
  //                       },
  //                       child: Text("Registrasi"),
  //                     ),
  //                   ],
  //                 ),
  //               ),
  //             ),
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
                        "GoLab App",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 24.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),

                        
                      ),
             SizedBox(height: 16.0),
            _entryField('Email', _controllerEmail),
             SizedBox(height: 16.0),
            _entryField('Password', _controllerPassword),
             SizedBox(height: 16.0),
            _errorMessage(),
            _submitButton(),
            _loginOrRegisterButton(),
            SizedBox(height: 16.0),
                      
           
                     
          ],
        ),
      ),
    );
  }
}

// class LoginPage extends StatefulWidget {
//   const LoginPage({super.key});

//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }
// class _LoginPageState extends State<LoginPage> {
//   String? errorMessage = '';
//   bool isLogin = true;

//   final TextEditingController _controllerEmail = TextEditingController();
//   final TextEditingController _controllerPassword = TextEditingController();

//   Future<void> signInWithEmailAndPassword() async {
//     try {
//       await Auth().signInWithEmailAndPassword(
//           email: _controllerEmail.text, password: _controllerPassword.text);
//     } on FirebaseAuthException catch (e) {
//       setState(() {
//         errorMessage = e.message;
//       });
//     }
//   }

//   Future<void> createUserWithEmailAndPassword() async {
//     try {
//       await Auth().createUserWithEmailAndPassword(
//           email: _controllerEmail.text, password: _controllerPassword.text);
//     } on FirebaseAuthException catch (e) {
//       setState(() {
//         errorMessage = e.message;
//       });
//     }
//   }

//   Widget _title() {
//     return const Text('Firebase Auth');
//   }

//   Widget _entryField(String title, TextEditingController controller) {
//     return TextField(
//       controller: controller,
//       decoration: InputDecoration(
//         labelText: title,
//       ),
//     );
//   }

//   Widget _errorMessage() {
//     return Text(errorMessage == '' ? '' : 'Humm ? $errorMessage');
//   }

//   Widget _submitButton() {
//     return ElevatedButton(
//       onPressed:
//           isLogin ? signInWithEmailAndPassword : createUserWithEmailAndPassword,
//       child: Text(isLogin ? 'Login' : 'Register'),
//     );
//   }

//   Widget _loginOrRegisterButton() {
//     return TextButton(
//       onPressed: () {
//         setState(() {
//           isLogin = !isLogin;
//         });
//       },
//       child: Text(isLogin ? 'Register' : 'Login'),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: _title(),
//       ),
//       body: Container(
//         height: double.infinity,
//         width: double.infinity,
//         padding: EdgeInsets.all(20),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: <Widget>[
//             _entryField('email', _controllerEmail),
//             _entryField('password', _controllerPassword),
//             _errorMessage(),
//             _submitButton(),
//             _loginOrRegisterButton(),
//           ],
//         ),
//       ),
//     );
//   }
// }