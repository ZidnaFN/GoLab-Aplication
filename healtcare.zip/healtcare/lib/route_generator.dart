import 'package:flutter/material.dart';
import 'package:healtcare/pages/hasil_page.dart';
//import 'package:navigation/pages/error_page.dart';
//import 'package:navigation/pages/main_page.dart';
//import 'package:navigation/pages/second_page.dart';
import 'package:healtcare/pages/login_pages.dart';
import 'package:healtcare/pages/regist_pages.dart';
import 'package:healtcare/widget_tree_home.dart';
import 'package:healtcare/pages/home_page.dart';
import 'package:healtcare/pages/hasil_page.dart';
import 'package:healtcare/pages/form_page.dart';
import 'package:healtcare/pages/struk_page.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const MainPage());
      case '/one':
        return MaterialPageRoute(builder: (_) => const MainPage());
      case '/second':
        return MaterialPageRoute(builder: (_) => SecondPage("Hello"));
      case '/third':
        return MaterialPageRoute(builder: (_) => const Hasil());
      case '/five':
        return MaterialPageRoute(builder: (_) => const MyForm());
      case '/sixth':
        return MaterialPageRoute(builder: (_) => const Struk());
      case '/seventh':
        return MaterialPageRoute(builder: (_) => const WidgetTree2());
      default:
      return MaterialPageRoute(builder: (_) => const MyApp());
    }
  }
}
