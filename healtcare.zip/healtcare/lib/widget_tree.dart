import 'package:healtcare/auth.dart';


import 'package:flutter/material.dart';
import 'package:healtcare/pages/home_page.dart';
import 'package:healtcare/pages/login_pages.dart';

class WidgetTree extends StatefulWidget {
  const WidgetTree({super.key});

  @override
  State<WidgetTree> createState() => _WidgetTreeState();
}

class _WidgetTreeState extends State<WidgetTree> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: Auth().authStateChanges,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return MyApp();
          } else {
            return MainPage();
          }
        });
  }
}
